/**
 * funkcja pobiera imię użytkownika i zwraca powitanie z nim
 * @param {string} somebody imię użytkownika
 *
 * @returns None (`undefined`)
 *
 * @author Wojciech Weiss 5D
 */

const sayHello = (somebody) => {
    alert(`hello ${somebody}`);
}