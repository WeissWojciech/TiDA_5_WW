/**
 * funkcja dzieli dzwie liczby podane w parametrach
 * @param {number} a - licznik
 * @param {number} b - mianownik
 * @throws {Error} if `b` is 0
 * @returns {number} - wynik dzielenia a przez b
 * @example
 * const a=10;
 * const b=5;
 *
 * const result = divide(a,b);
 * console.log(result)
 * //logs : 2
 *
 * @author Wojciech Weiss 5D
 */

function divide(a,b) {
    if(b!==0){
        return a/b;
    }
    else return "you can't devidie by 0!";
}
const wynik = divide(4,0);
console.log(wynik);