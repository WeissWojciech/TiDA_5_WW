/**
 *
 * function calculate area of circle
 * @param r - radius of circle
 * @throws {Error} if `r` is lower or equal 0
 * @returns {number} returns area of circle
 *
 * @author Wojciech Weiss 5D
 */

function calculateArea(r) {
    if (r > 0) {
        return Math.PI * r * r;
    }
    else return "promień musi być dodatni";
}
const wynik = calculateArea(2);
console.log(wynik);