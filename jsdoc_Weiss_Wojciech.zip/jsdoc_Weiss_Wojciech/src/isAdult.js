/**
 * funkcja sprawdza czy opsoba, której wiek podajemy jest osobą pelnoletnią czy też nie
 * @param age - podany wiek
 * @returns {string|boolean} - wynik wypisze `true` lub `false` w zależmości od wyniku lub tekst błędu
 *
 * @example
 * const age=20;
 *
 * const result = isAdult(age);
 * console.log(result)
 * //logs : true
 *
 * @throws {Error} - kiedy podany wiek będzie mniejszy lub równy 0
 *
 * @author Wojciech Weiss 5D
 */

function isAdult (age) {
    if (age < 0) {
        if (age < 18) {
            return false;
        }
        return true;
    }
    else return "wiek nie może być mniejszy od zera"
}

const someone = isAdult(19);
console.log(someone);