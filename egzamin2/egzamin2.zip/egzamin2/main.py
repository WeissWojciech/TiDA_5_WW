
"""
nazwa funkcji: check_gender
opis funkcji: funkcja sprawdza czy przed ostatnia liczba peselu jest parzysta, czy nie. Jeżeli tak zwraca K, a jeżeli nie "M"
parametry: `pesel` - ciąg znaków, przechowuje numer pesel
zwracane typy i opis: funkcja zwraca string "M" lub "K" w zależności od wyniku działania na numerze pesel
autor: Wojciech Weiss 5D
"""

def check_gender(pesel):
    if int(pesel[9]) % 2 == 1:
        return "M"
    else:
        return "K"

def check_pesel(pesel):
    if len(pesel) != 11 or not pesel.isdigit():
        return False

    weights = [1, 3, 7, 9, 1, 3, 7, 9, 1, 3]
    s = sum(int(pesel[i]) * weights[i] for i in range(10))
    m = s % 10
    if m == 0:
        r = 0
    else:
        r = (10 - m)
    return r == int(pesel[-1])

"""pesel = "55030101193"""
pesel = input("Enter a pesel number: ")
if check_pesel(pesel):
    print("PESEL jest poprawny.")
    print("Płeć: " + check_gender(pesel) )
else:
    print("PESEL jest niepoprawny.")
